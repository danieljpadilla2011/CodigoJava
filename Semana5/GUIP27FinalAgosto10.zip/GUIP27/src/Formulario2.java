import javax.swing.JFrame;

public class Formulario2 {
    public static void main(String[] args) {
        JFrame f = new JFrame();
        f.setBounds(10, 10, 300, 180);
        f.setVisible(true);
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

}
