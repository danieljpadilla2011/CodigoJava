import java.awt.Color;
import java.awt.Dimension;
import javax.swing.*;

public class FormularioPanel extends JFrame {
    private JPanel panel, panel2;
    private JLabel lblMsg;
    private JButton btn1, btn2;

    public FormularioPanel() {
        setLayout(null);
        panel = new JPanel();
        panel.setBounds(430, 10, 200, 200);
        panel.setBackground(Color.CYAN);
        panel.setLayout(null);
        add(panel);

        lblMsg = new JLabel("Mision Tic 2022");
        lblMsg.setBounds(20, 20, 60, 30);
        panel.add(lblMsg);

        btn1 = new JButton("Aceptar");
        btn1.setBounds(50, 90, 100, 30);
        panel.add(btn1);

        panel2 = new JPanel();
        panel2.setBounds(220, 10, 200, 200);
        panel2.setBackground(Color.GREEN);
        panel2.setLayout(null);
        add(panel2);

        btn2 = new JButton("Aceptar");
        btn2.setBounds(50, 90, 100, 30);
        panel2.add(btn2);

    }

}
