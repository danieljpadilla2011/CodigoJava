import javax.swing.JComboBox;
import javax.swing.JFrame;
import java.awt.event.*;

public class FormularioCb extends JFrame implements ItemListener {
    private JComboBox<String> cmbColores;

    public FormularioCb() {
        setLayout(null);
        cmbColores = new JComboBox<String>();
        cmbColores.setBounds(10, 10, 90, 20);
        add(cmbColores);
        cmbColores.addItem("rojo");
        cmbColores.addItem("verde");
        cmbColores.addItem("azul");
        cmbColores.addItem("amarillo");
        cmbColores.addItem("negro");
        cmbColores.addItemListener(this);

    }

    @Override
    public void itemStateChanged(ItemEvent e) {
        if (e.getSource() == cmbColores) {
            String seleccion = (String) cmbColores.getSelectedItem();
            setTitle(seleccion);
        }
    }

    public static void main(String[] args) {
        FormularioCb formulario = new FormularioCb();
        formulario.setBounds(0, 0, 200, 160);
        formulario.setVisible(true);
        formulario.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

}
