import javax.swing.ButtonGroup;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JRadioButton;
import javax.swing.event.*;

public class FormularioRB extends JFrame implements ChangeListener {
    private JRadioButton radio1, radio2, radio3;
    private ButtonGroup bg;
    private JLabel lblNom;

    public FormularioRB() {
        setLayout(null);
        bg = new ButtonGroup();

        radio1 = new JRadioButton("Colombia");
        radio1.setBounds(10, 20, 100, 30);
        add(radio1);
        bg.add(radio1);
        radio1.addChangeListener(this);

        radio2 = new JRadioButton("Perú");
        radio2.setBounds(10, 60, 100, 30);
        add(radio2);
        bg.add((radio2));
        radio2.addChangeListener(this);

        radio3 = new JRadioButton("Ecuador");
        radio3.setBounds(10, 100, 100, 30);
        add(radio3);
        bg.add(radio3);
        radio3.addChangeListener(this);

        lblNom = new JLabel("");
        lblNom.setBounds(10, 130, 200, 30);
        add(lblNom);

    }

    @Override
    public void stateChanged(ChangeEvent e) {
        if (radio1.isSelected()) {
            lblNom.setText("Colombia");
        }
        if (radio2.isSelected()) {
            lblNom.setText("Perú");
        }
        if (radio3.isSelected()) {
            lblNom.setText("Ecuador");
        }

    }

}
