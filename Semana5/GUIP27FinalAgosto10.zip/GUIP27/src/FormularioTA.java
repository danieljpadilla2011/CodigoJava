import javax.swing.*;

public class FormularioTA extends JFrame {
    private JTextField cmpEmail;
    private JTextArea cmpArea;
    private JScrollPane scrollpanel;

    public FormularioTA() {
        setLayout(null);
        cmpEmail = new JTextField();
        cmpEmail.setBounds(10, 10, 200, 30);
        add(cmpEmail);

        cmpArea = new JTextArea();
        // cmpArea.setBounds(10, 50, 400, 300);
        // add(cmpArea);

        scrollpanel = new JScrollPane(cmpArea);
        scrollpanel.setBounds(10, 50, 400, 300);
        add(scrollpanel);

    }

    public static void main(String[] args) {
        FormularioTA formulario = new FormularioTA();
        formulario.setBounds(0, 0, 600, 450);
        formulario.setVisible(true);
        formulario.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

}
