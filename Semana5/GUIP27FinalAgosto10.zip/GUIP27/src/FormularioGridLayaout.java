import javax.swing.*;
import javax.swing.border.LineBorder;
import static java.awt.Font.PLAIN;
import java.awt.*;

public class FormularioGridLayaout extends JFrame {

    private FlowLayout miFlowLayout;
    private JLabel lblDisplay;
    private JPanel panelBotones;
    private GridLayout miGridLayaout;
    private JButton boton[], botonResultado;

    public FormularioGridLayaout() {
        Display();
        Botones();
        BotonResultado();
        pantalla();
    }

    private void pantalla() {
        miFlowLayout = new FlowLayout(FlowLayout.CENTER, 10, 10);
        setLayout(miFlowLayout);
        setTitle("Calculadora");
        setMinimumSize(new Dimension(255, 405));
        setResizable(false);
        setLocationRelativeTo(null);
        getContentPane().setBackground(Color.black);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }

    private void Display() {
        lblDisplay = new JLabel("0");
        lblDisplay.setPreferredSize(new Dimension(230, 60));
        lblDisplay.setBackground(Color.BLACK);
        lblDisplay.setForeground(Color.green);
        lblDisplay.setBorder(new LineBorder(Color.GRAY));
        lblDisplay.setFont(new Font("MONOSPACED", PLAIN, 24));
        lblDisplay.setHorizontalAlignment(SwingConstants.RIGHT);
        add(lblDisplay);
    }

    private void Botones() {
        panelBotones = new JPanel();
        panelBotones.setBackground(Color.black);
        miGridLayaout = new GridLayout(4, 4, 10, 10);
        panelBotones.setLayout(miGridLayaout);
        add(panelBotones);

        String[] texto_boton = new String[] { "0", ".", "C", "+", "1", "2", "3", "-", "4", "5", "6", "*", "7", "8", "9",
                "/", };

        boton = new JButton[16];

        for (int i = 0; i <= 15; i++) {
            boton[i] = new JButton(texto_boton[i]);
            boton[i].setPreferredSize(new Dimension(50, 50));
            boton[i].setFont(new Font("MONOSPACED", PLAIN, 16));
            boton[i].setBackground(Color.DARK_GRAY);
            boton[i].setBorder(new LineBorder(Color.DARK_GRAY));
            boton[i].setForeground(Color.WHITE);
            panelBotones.add(boton[i]);

        }

    }

    private void BotonResultado() {
        botonResultado = new JButton("RESULTADO");
        botonResultado.setPreferredSize(new Dimension(230, 50));
        botonResultado.setFont(new Font("MONOSPACED", PLAIN, 16));
        botonResultado.setBackground(Color.DARK_GRAY);
        botonResultado.setBorder(new LineBorder(Color.DARK_GRAY));
        botonResultado.setForeground(Color.WHITE);
        add(botonResultado);

    }

}
