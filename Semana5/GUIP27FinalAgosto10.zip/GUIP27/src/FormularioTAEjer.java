import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

import java.awt.event.*;

public class FormularioTAEjer extends JFrame implements ActionListener {
    private JScrollPane scrollPanel1;
    private JTextArea textArea1;
    private JButton boton1;

    public FormularioTAEjer() {
        setLayout(null);
        textArea1 = new JTextArea();
        scrollPanel1 = new JScrollPane(textArea1);
        scrollPanel1.setBounds(10, 10, 300, 200);
        add(scrollPanel1);
        boton1 = new JButton("Verficar");
        boton1.setBounds(10, 250, 100, 30);
        add(boton1);
        boton1.addActionListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == boton1) {
            String texto = textArea1.getText();
            if (texto.indexOf("programa") != -1) {
                setTitle("Si contiene el texto");
            } else {
                setTitle("No contiene el texto");

            }

        }

    }

    public static void main(String[] args) {
        FormularioTAEjer formulario = new FormularioTAEjer();
        formulario.setBounds(0, 0, 400, 400);
        formulario.setVisible(true);
        formulario.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

}
