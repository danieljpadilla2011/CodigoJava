import javax.swing.*;
import javax.swing.JLabel;

import java.awt.event.*;

public class FormularioTF extends JFrame implements ActionListener {
    private JTextField cmpUsuario;
    private JLabel lblUsuario;
    private JButton btnAceptar;

    public FormularioTF() {
        setLayout(null);
        lblUsuario = new JLabel("Usuario");
        lblUsuario.setBounds(10, 10, 100, 30);
        add(lblUsuario);
        cmpUsuario = new JTextField();
        cmpUsuario.setBounds(120, 10, 150, 30);
        add(cmpUsuario);
        btnAceptar = new JButton("Aceptar");
        btnAceptar.setBounds(10, 70, 100, 30);
        add(btnAceptar);
        btnAceptar.addActionListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == btnAceptar) {
            String cad = cmpUsuario.getText();
            setTitle(cad);
            // lblUsuario.setText(cad);
            // cmpUsuario.setText("Valor Establecido");
        }

    }

    public static void main(String[] args) {
        FormularioTF formulario = new FormularioTF();
        formulario.setBounds(0, 0, 350, 200);
        formulario.setVisible(true);
        formulario.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

}
