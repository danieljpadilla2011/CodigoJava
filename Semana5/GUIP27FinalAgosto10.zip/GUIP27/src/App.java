import javax.swing.JFrame;

public class App {
    public static void main(String[] args) throws Exception {
        //new FormularioGridLayaout();
        
        FormularioPanel formulario = new FormularioPanel();
        formulario.setBounds(0, 0, 600, 600);
        formulario.setSize(350, 200);
        formulario.setLocationRelativeTo(null);
        formulario.setVisible(true);
        formulario.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

    }
}
