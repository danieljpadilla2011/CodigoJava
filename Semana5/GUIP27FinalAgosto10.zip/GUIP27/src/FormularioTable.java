import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.event.*;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public class FormularioTable extends JFrame {

    public FormularioTable() {
        String[] columnNames = { "Nombre", "Años", "Apto" };
        Object[][] datos = { { "Juan", 25, false }, { "Sonia", 33, true }, { "Pedro", 42, false }, };
        DefaultTableModel dtm = new DefaultTableModel(datos, columnNames);
        final JTable table = new JTable(dtm);

        Object[] nuevafila = { "Maria", 55, false };
        dtm.addRow(nuevafila);

        dtm.setValueAt("YES", 2, 2);

        table.setPreferredScrollableViewportSize(new Dimension(250, 100));
        JScrollPane scrollPane = new JScrollPane(table);
        getContentPane().add(scrollPane, BorderLayout.CENTER);

        // addWindowListener(new WindowAdapter() {
        // public void windowClosing(WindowEvent e) {
        // System.exit(0);
        // }

        // });

    }

    public static void main(String[] args) {
        FormularioTable ventana = new FormularioTable();
        ventana.pack();
        ventana.setVisible(true);
        ventana.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

    }

}
