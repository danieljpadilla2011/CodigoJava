import javax.swing.JButton;
import javax.swing.JFrame;
import java.awt.event.*;
import java.awt.*;

public class FormularioFlowLayout extends JFrame implements ActionListener {
    private JButton boton1, boton2, boton3, boton4, boton5;
    private FlowLayout miFlowLayout;

    public FormularioFlowLayout() {
        miFlowLayout = new FlowLayout(FlowLayout.CENTER, 3, 3);
        setLayout(miFlowLayout);

        boton1 = new JButton("Botón 1");
        boton2 = new JButton("Botón 2");
        boton3 = new JButton("Botón 3");
        boton4 = new JButton("Botón 4");
        boton5 = new JButton("Botón 5");
        add(boton1);
        add(boton2);
        add(boton3);
        add(boton4);
        add(boton5);

        boton1.addActionListener(this);
        boton2.addActionListener(this);
        boton3.addActionListener(this);
        boton4.addActionListener(this);
        boton5.addActionListener(this);

    }

    @Override
    public void actionPerformed(ActionEvent e) {
        miFlowLayout.setHgap(miFlowLayout.getHgap() + 5);
        miFlowLayout.setVgap(miFlowLayout.getVgap() + 5);
        setLayout(miFlowLayout);
        validate();

    }

}
